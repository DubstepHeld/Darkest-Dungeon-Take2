﻿using UnityEngine;

public class SimpleRaces : MonoBehaviour {
    //reiner Spritespeicher für MainMenu
    public Sprite[] idle;
}
